import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar-minimizer',
  templateUrl: './app-sidebar-minimizer.component.html'
})
export class AppSidebarMinimizerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}