import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar-footer',
  templateUrl: './app-sidebar-footer.component.html'
})
export class AppSidebarFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}